import tkinter as tk, csv, random, os, time, math
from tkinter import PhotoImage, simpledialog, filedialog, messagebox as msgbox 

class QuizApp:
    def __init__(self, master, questions):
        self.master = master
        self.questions = questions
        self.current_question = 0
        self.selected_option = tk.StringVar(value='')
        
        self.question_label = tk.Label(master, text='', font=('Arial', 14))
        self.question_label.grid(pady=10)

        self.question_number_label = tk.Label(master, text=f"Question {self.current_question + 1} of {len(self.questions)}", font=('Arial', 12))
        self.question_number_label.grid(row=0, column=1, padx=10, pady=10, sticky="E")
        
        self.option_a_button = tk.Radiobutton(master, text='', variable=self.selected_option, value='A', font=('Arial', 12))
        self.option_b_button = tk.Radiobutton(master, text='', variable=self.selected_option, value='B', font=('Arial', 12))
        self.option_c_button = tk.Radiobutton(master, text='', variable=self.selected_option, value='C', font=('Arial', 12))
        self.option_d_button = tk.Radiobutton(master, text='', variable=self.selected_option, value='D', font=('Arial', 12))
        self.option_a_button.grid()
        self.option_b_button.grid()
        self.option_c_button.grid()
        self.option_d_button.grid()
        
        self.check_button = tk.Button(master, text='Check', font=('Arial', 12), command=self.check_answer,anchor="w")
        self.check_button.config(justify='left')
        self.check_button.grid(pady=10)
        
        self.next_button = tk.Button(master, text='Next', font=('Arial', 12), command=self.next_question,anchor="w")
        self.next_button.config(state=tk.DISABLED,justify="left")
        self.next_button.grid(pady=10)

        self.display_question(self.current_question)
    
    def display_question(self, index):
        self.question_label.config(text=self.questions[index]['question'],justify="left") 
        self.question_label.grid(row=0, column=0, sticky='w')
        self.option_a_button.config(text=self.questions[index]['option_a'],justify="left")
        self.option_a_button.grid(row=1, column=0, sticky='w')
        self.option_b_button.config(text=self.questions[index]['option_b'],justify="left")
        self.option_b_button.grid(row=2, column=0, sticky='w')
        self.option_c_button.config(text=self.questions[index]['option_c'],justify="left")
        self.option_c_button.grid(row=3, column=0, sticky='w')
        self.option_d_button.config(text=self.questions[index]['option_d'],justify="left")
        self.option_d_button.grid(row=4, column=0, sticky='w')
        self.selected_option.set('')
        self.check_button.config(state=tk.NORMAL,justify="left")
        self.next_button.config(state=tk.DISABLED,justify="left")
    
    def check_answer(self):
        answer = self.selected_option.get()
        if answer == self.questions[self.current_question]['correct_option']:
            self.question_label.config(text=self.questions[index]['question'],justify="left") 
            self.question_label.grid(row=0, column=0, sticky='w')
            self.question_label.config(text='Correct!')
        else:
            self.question_label.config(text='Incorrect.')
        self.check_button.config(state=tk.DISABLED)
        self.next_button.config(state=tk.NORMAL)
    
    def next_question(self):
        self.current_question += 1
        if self.current_question >= len(self.questions):
            self.question_label.config(text='End of quiz.')
            self.option_a_button.grid_forget()
            self.option_b_button.grid_forget()
            self.option_c_button.grid_forget()
            self.option_d_button.grid_forget()
            self.check_button.grid_forget()
            self.next_button.grid_forget()
        else:
            self.display_question(self.current_question)


def load_questions(filename):
    questions = []
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            questions.append(row)
    return questions

def shuffle_questions(questions):
    random.shuffle(questions)

def on_test_button_click():
    global yesno_button
    yesno_button = None
    file_path = filedialog.askopenfilename(title="Select Test Questions")
    print(file_path)
    
    if not file_path:
        if yesno_button is not None:
            yesno_button.grid_forget()
        return

    if yesno_button is None:
        yesno_button = tk.Button(root, text="Start Test!", command=lambda: on_yesno_click(file_path))
        yesno_button.grid()
    else:
        yesno_button.config(text="Start Test!", command=lambda: on_yesno_click(file_path))

def hide_menu_widgets():
    label.grid_forget()
    test_selection.grid_forget()
    statement.grid_forget()

def on_yesno_click(file_path):
    result = msgbox.askyesno("Question", f"You are about to load {file_path} and take a test on it.\n\n\tContinue?")
    if result:
        if os.path.exists(file_path):
            questions = load_questions(file_path)
            shuffle_questions(questions)
            hide_menu_widgets()
            quiz = QuizApp(root, questions)
            yesno_button.grid_forget()
    
    else:
        yesno_button.grid_forget()

    quiz.master.mainloop()

def developer_statement():
    with open('statement.txt', 'r') as f:
        text = f.read()

    # Create a new window for the text widget
    statement_window = tk.Toplevel(root)

    # Create the text widget and add it to the window
    statement_text = tk.Text(statement_window, width=80, height=20)
    statement_text.pack()

    # Insert the contents of the file into the text widget
    statement_text.insert('1.0', text)

    # Make the window visible
    statement_window.mainloop()

if __name__ == '__main__':
    root = tk.Tk()
    root.title("Test N Jhin")
    root.state('zoomed')
    root.colormapwindows()

    label = tk.Label(root, text="""
~~~ WELCOME TO ~~~
 _____         _     _   _     ___ _     _       
|_   _|       | |   | \ | |   |_  | |   (_)      
  | | ___  ___| |_  |  \| |     | | |__  _ _ __  
  | |/ _ \/ __| __| | . ` |     | | '_ \| | '_ \ 
  | |  __/\__ \ |_  | |\  | /\__/ / | | | | | | |
  \_/\___||___/\__| \_| \_/ \____/|_| |_|_|_| |_|
\n\n""", font=("Courier", 16))   
    label.grid()
    icon = PhotoImage(file="TNJ_Window_Icon.png")
    root.wm_iconphoto(True, icon)

    test_selection = tk.Button(root, text="Select Test Bank", command=on_test_button_click)
    test_selection.config()
    test_selection.grid()

    global statement
    statement = tk.Button(root, text="Developer's Statement", command=developer_statement)
    statement.config()
    statement.grid()



root.mainloop()